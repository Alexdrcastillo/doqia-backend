from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
import os
from flask import send_file

# Importar Stripe
import stripe

app = Flask(__name__)

# Configuración de CORS
CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})

# Configuración de las claves de Stripe
app.config['STRIPE_PUBLIC_KEY'] = 'pk_test_51PZ2OyGpQaucOZIPCeji7BENlnaUH9emeodQQs0SJjFRLi83TKx6mTAoYLfxY0Lwtp7kXlVJMKsB2zmKrRvVMmkL00n9ncqLh2'
app.config['STRIPE_SECRET_KEY'] = 'sk_test_51PZ2OyGpQaucOZIPg8Qasu2SRP9Hy3c6QgHPfF8rUcKzzef7KFvW3lYhyqa49YAQdyvxNiEQhEX8xCZ3vuvJEaTO00tWIRqPHz'

# Configuración de la base de datos para MySQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:Facil13-@localhost/database_doqia'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')  # Ruta absoluta a la carpeta uploads
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = ALLOWED_EXTENSIONS

# Inicializar SQLAlchemy y Migrate
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Importa tus rutas al final para evitar referencias circulares
from app import routes

# Configurar Stripe
stripe.api_key = app.config['STRIPE_SECRET_KEY']

if __name__ == "__main__":
    app.run(debug=True)

